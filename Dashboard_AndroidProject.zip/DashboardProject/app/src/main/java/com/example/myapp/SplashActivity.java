package com.example.myapp;

// Splash Activity placeholder